export interface Food
{
    id?:number,
    name:string;
    photos:string;
    price:number;
    category:string;
}